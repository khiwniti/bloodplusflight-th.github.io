import { createServerComponentClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { checkUserPermission } from '@/lib/auth-utils'

export default async function AdminDashboard() {
  const supabase = createServerComponentClient({ cookies })
  
  const { data: { user }, error: authError } = await supabase.auth.getUser()
  if (authError || !user) {
    redirect('/login')
  }

  const canManageUsers = await checkUserPermission('manage_users')
  const canManageRoles = await checkUserPermission('manage_roles')
  const canManageAlerts = await checkUserPermission('manage_alerts')
  const canEditContent = await checkUserPermission('edit_content')
  const canViewAnalytics = await checkUserPermission('view_analytics')
  const canManageSystem = await checkUserPermission('manage_system')

  if (!canManageSystem) {
    redirect('/dashboard')
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Admin Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {canManageUsers && (
          <Link href="/admin/users" passHref>
            <Button className="w-full h-32 text-lg">Manage Users</Button>
          </Link>
        )}
        {canManageRoles && (
          <Link href="/admin/roles" passHref>
            <Button className="w-full h-32 text-lg">Manage Roles</Button>
          </Link>
        )}
        {canManageAlerts && (
          <Link href="/admin/alerts" passHref>
            <Button className="w-full h-32 text-lg">Manage Alerts</Button>
          </Link>
        )}
        {canEditContent && (
          <Link href="/admin/content" passHref>
            <Button className="w-full h-32 text-lg">Edit Content</Button>
          </Link>
        )}
        {canViewAnalytics && (
          <Link href="/admin/analytics" passHref>
            <Button className="w-full h-32 text-lg">View Analytics</Button>
          </Link>
        )}
        {canManageSystem && (
          <Link href="/admin/system" passHref>
            <Button className="w-full h-32 text-lg">System Settings</Button>
          </Link>
        )}
      </div>
    </div>
  )
}

