import { createServerComponentClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { redirect } from 'next/navigation'
import { checkUserPermission } from '@/lib/auth-utils'
import SystemSettingsForm from '@/components/admin/system-settings-form'

export default async function SystemSettings() {
  const supabase = createServerComponentClient({ cookies })
  
  const { data: { user }, error: authError } = await supabase.auth.getUser()
  if (authError || !user) {
    redirect('/login')
  }

  const canManageSystem = await checkUserPermission('manage_system')

  if (!canManageSystem) {
    redirect('/dashboard')
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">System Settings</h1>
      <SystemSettingsForm />
    </div>
  )
}

