import { createServerComponentClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { redirect } from 'next/navigation'
import { checkUserPermission } from '@/lib/auth-utils'
import UserList from '@/components/admin/user-list'
import UserRoleForm from '@/components/admin/user-role-form'

export default async function ManageUsers() {
  const supabase = createServerComponentClient({ cookies })
  
  const { data: { user }, error: authError } = await supabase.auth.getUser()
  if (authError || !user) {
    redirect('/login')
  }

  const canManageUsers = await checkUserPermission('manage_users')

  if (!canManageUsers) {
    redirect('/dashboard')
  }

  const { data: users, error: usersError } = await supabase
    .from('auth.users')
    .select('id, email')

  if (usersError) {
    console.error("Error fetching users:", usersError)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Manage Users</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <h2 className="text-2xl font-semibold mb-4">User List</h2>
          <UserList users={users || []} />
        </div>
        <div>
          <h2 className="text-2xl font-semibold mb-4">Assign Role</h2>
          <UserRoleForm />
        </div>
      </div>
    </div>
  )
}

