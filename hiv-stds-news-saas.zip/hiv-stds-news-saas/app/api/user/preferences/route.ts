import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"
import { getServerSession } from "next-auth/next"

const prisma = new PrismaClient()

export async function POST(request: Request) {
  const session = await getServerSession()
  
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const { keywords, sources, severity } = await request.json()
  
  const preference = await prisma.alertPreference.create({
    data: {
      userId: session.user.id,
      keywords,
      sources,
      severity,
    },
  })

  return NextResponse.json(preference)
}

