import { NextResponse } from "next/server"
import { Client } from '@line/bot-sdk'

const client = new Client({
  channelAccessToken: process.env.LINE_CHANNEL_ACCESS_TOKEN,
  channelSecret: process.env.LINE_CHANNEL_SECRET,
})

export async function POST(request: Request) {
  const { message, userId } = await request.json()

  try {
    await client.pushMessage(userId, { type: 'text', text: message })
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error handling Line webhook:', error)
    return NextResponse.json({ error: 'Failed to send Line message' }, { status: 500 })
  }
}

