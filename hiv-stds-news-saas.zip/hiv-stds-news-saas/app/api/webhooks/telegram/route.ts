import { NextResponse } from "next/server"
import { Telegraf } from 'telegraf'

const bot = new Telegraf(process.env.TELEGRAM_BOT_TOKEN)

bot.launch()

export async function POST(request: Request) {
  const { message, userId } = await request.json()

  try {
    await bot.telegram.sendMessage(userId, message)
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error handling Telegram webhook:', error)
    return NextResponse.json({ error: 'Failed to send Telegram message' }, { status: 500 })
  }
}

