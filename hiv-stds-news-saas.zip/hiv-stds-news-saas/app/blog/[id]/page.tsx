import { notFound } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"

// Mock data
const blogPosts = [
  {
    id: '1',
    title: 'Understanding HIV Transmission',
    content: "HIV transmission occurs through specific bodily fluids. The most common ways that HIV is transmitted are through anal or vaginal sex and sharing needles, syringes, or other drug injection equipment with someone who has HIV. Less commonly, HIV can be transmitted from mother to child during pregnancy, birth, or breastfeeding. It's important to note that HIV does not survive long outside the human body and cannot reproduce outside a human host. It is not spread by air, water, insects, saliva, tears, casual contact, or sharing toilets, food, or drinks.",
    createdAt: new Date().toISOString(),
    newsItem: { 
      source: 'CDC',
      url: 'https://www.cdc.gov/hiv/basics/transmission.html'
    }
  },
  {
    id: '2',
    title: 'The Importance of Regular STD Testing',
    content: 'Regular STD testing is crucial for maintaining sexual health and preventing the spread of infections. Many STDs can be asymptomatic, meaning they don\'t show any visible signs or symptoms. This makes regular testing the only reliable way to know your status. Early detection through testing allows for prompt treatment, which can prevent long-term health complications and reduce the risk of transmission to partners. The frequency of testing depends on individual risk factors, but sexually active individuals should generally get tested at least once a year. Remember, getting tested is a responsible and empowering act of self-care.',
    createdAt: new Date().toISOString(),
    newsItem: { 
      source: 'WHO',
      url: 'https://www.who.int/news-room/fact-sheets/detail/sexually-transmitted-infections-(stis)'
    }
  },
]

export default function BlogPost({ params }: { params: { id: string } }) {
  const post = blogPosts.find(post => post.id === params.id)

  if (!post) {
    notFound()
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-4">{post.title}</h1>
      <p className="text-sm text-muted-foreground mb-4">
        Published on {new Date(post.createdAt).toLocaleDateString()} | 
        Source: {post.newsItem.source}
      </p>
      <div className="prose dark:prose-invert max-w-none mb-6">
        {post.content.split('\n').map((paragraph, index) => (
          <p key={index}>{paragraph}</p>
        ))}
      </div>
      <Button asChild>
        <Link href={post.newsItem.url} target="_blank" rel="noopener noreferrer">
          Read Original Article
        </Link>
      </Button>
    </div>
  )
}

