"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { X } from 'lucide-react'

type Alert = {
  id: string
  title: string
  content: string
  severity: "LOW" | "MEDIUM" | "HIGH"
}

export default function AlertBanner() {
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [currentAlertIndex, setCurrentAlertIndex] = useState(0)

  useEffect(() => {
    const fetchAlerts = async () => {
      try {
        const response = await fetch("/api/alerts")
        if (response.ok) {
          const data = await response.json()
          setAlerts(data)
        }
      } catch (error) {
        console.error("Failed to fetch alerts:", error)
      }
    }
    fetchAlerts()
  }, [])

  const dismissAlert = () => {
    setAlerts(alerts.filter((_, index) => index !== currentAlertIndex))
    setCurrentAlertIndex(0)
  }

  useEffect(() => {
    if (alerts.length > 1) {
      const timer = setInterval(() => {
        setCurrentAlertIndex((prevIndex) => (prevIndex + 1) % alerts.length)
      }, 5000)
      return () => clearInterval(timer)
    }
  }, [alerts])

  if (alerts.length === 0) return null

  const currentAlert = alerts[currentAlertIndex]

  return (
    <AnimatePresence>
      <motion.div
        key={currentAlert.id}
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -50 }}
        className={`fixed top-0 left-0 right-0 z-50 p-4 ${
          currentAlert.severity === "HIGH" ? "bg-red-500" :
          currentAlert.severity === "MEDIUM" ? "bg-yellow-500" : "bg-green-500"
        }`}
      >
        <div className="container mx-auto flex items-center justify-between">
          <div>
            <h3 className="font-bold">{currentAlert.title}</h3>
            <p className="text-sm">{currentAlert.content}</p>
          </div>
          <button onClick={dismissAlert} className="text-white hover:text-gray-200">
            <X size={24} />
          </button>
        </div>
      </motion.div>
    </AnimatePresence>
  )
}

