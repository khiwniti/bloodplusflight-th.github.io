import Link from 'next/link'
import Image from 'next/image'

export default function Footer() {
  return (
    <footer className="bg-secondary text-white mt-8">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Image 
                src="/temp_image_8eeb2456-3735-44bd-ae00-02d053d5a826.png.jpg" 
                alt="Red AIDS awareness ribbon" 
                width={32} 
                height={38} 
                className="object-contain"
              />
              <span className="text-xl font-bold">GetInTheQ</span>
            </div>
            <p className="text-secondary-foreground">We are dedicated to providing up-to-date information and support for those affected by HIV and STDs.</p>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link href="/news" className="text-secondary-foreground hover:text-primary transition-colors">News</Link></li>
              <li><Link href="/blog" className="text-secondary-foreground hover:text-primary transition-colors">Blog</Link></li>
              <li><Link href="/chat" className="text-secondary-foreground hover:text-primary transition-colors">AI Chat</Link></li>
              <li><Link href="/privacy" className="text-secondary-foreground hover:text-primary transition-colors">Privacy Policy</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact</h3>
            <p className="text-secondary-foreground">Email: support@getintheq.io</p>
            <p className="text-secondary-foreground">Phone: (123) 456-7890</p>
          </div>
        </div>
        <div className="mt-8 text-center border-t border-secondary-foreground/20 pt-8">
          <p className="text-secondary-foreground">&copy; {new Date().getFullYear()} GetInTheQ. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

