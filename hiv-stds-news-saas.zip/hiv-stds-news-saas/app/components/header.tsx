import Link from 'next/link'
import Image from 'next/image'
import { Button } from '@/components/ui/button'
import { ModeToggle } from '@/components/mode-toggle'

export default function Header() {
  return (
    <header className="bg-background/50 backdrop-blur-md sticky top-0 z-50 border-b">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="/" className="flex items-center gap-2">
          <Image 
            src="/temp_image_8eeb2456-3735-44bd-ae00-02d053d5a826.png.jpg" 
            alt="Red AIDS awareness ribbon" 
            width={40} 
            height={48} 
            className="object-contain"
          />
          <span className="text-2xl font-bold text-secondary">GetInTheQ</span>
        </Link>
        <nav>
          <ul className="flex space-x-4 items-center">
            <li><Link href="/news" className="text-secondary hover:text-primary transition-colors">News</Link></li>
            <li><Link href="/blog" className="text-secondary hover:text-primary transition-colors">Blog</Link></li>
            <li><Link href="/chat" className="text-secondary hover:text-primary transition-colors">AI Chat</Link></li>
            <li><Button asChild variant="outline"><Link href="/login">Login</Link></Button></li>
            <li><Button asChild><Link href="/signup">Sign Up</Link></Button></li>
            <li><ModeToggle /></li>
          </ul>
        </nav>
      </div>
    </header>
  )
}

