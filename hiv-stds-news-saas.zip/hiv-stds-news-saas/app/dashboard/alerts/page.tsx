import { createServerComponentClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'
import { redirect } from "next/navigation"
import AlertForm from "@/components/alert-form"
import AlertList from "@/components/alert-list"
import UserPreferences from "@/components/user-preferences"

export default async function AlertsDashboard() {
  const supabase = createServerComponentClient({ cookies })
  
  const { data: { user }, error: authError } = await supabase.auth.getUser()
  if (authError || !user) {
    redirect("/login")
  }

  const { data: alerts, error: alertsError } = await supabase
    .from('alerts')
    .select('*')
    .order('created_at', { ascending: false })

  const { data: preferences, error: preferencesError } = await supabase
    .from('alert_preferences')
    .select('*')
    .eq('user_id', user.id)
    .single()

  if (alertsError || preferencesError) {
    console.error("Error fetching data:", alertsError || preferencesError)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Alerts Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <h2 className="text-2xl font-semibold mb-4">Your Alert Preferences</h2>
          <UserPreferences preferences={preferences || {}} />
        </div>
        <div>
          <h2 className="text-2xl font-semibold mb-4">Active Alerts</h2>
          <AlertList alerts={alerts || []} />
        </div>
      </div>
      {user.role === "admin" && (
        <div className="mt-8">
          <h2 className="text-2xl font-semibold mb-4">Create New Alert</h2>
          <AlertForm />
        </div>
      )}
    </div>
  )
}

