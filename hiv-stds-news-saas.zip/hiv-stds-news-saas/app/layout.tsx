import './globals.css'
import { Inter } from 'next/font/google'
import { ThemeProvider } from "@/components/theme-provider"
import Header from '@/app/components/header'
import Footer from '@/app/components/footer'
import AlertBanner from '@/app/components/alert-banner'

const inter = Inter({ subsets: ['latin'] })

export const metadata = {
  title: 'HIV/STDs News & Support',
  description: 'Real-time updates and support for HIV/STDs patients',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
          <div className="flex flex-col min-h-screen">
            <AlertBanner />
            <Header />
            <main className="flex-grow">{children}</main>
            <Footer />
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}

