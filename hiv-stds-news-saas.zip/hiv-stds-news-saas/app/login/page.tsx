"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { supabase } from "@/lib/supabase-client"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const router = useRouter()

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) {
      console.error("Error logging in:", error.message)
    } else {
      router.push("/dashboard")
    }
  }

  const handleSSOLogin = async (provider: 'google' | 'facebook') => {
    const { error } = await supabase.auth.signInWithOAuth({ provider })
    if (error) {
      console.error(`Error logging in with ${provider}:`, error.message)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-md mx-auto bg-secondary/50 backdrop-blur-md p-6 rounded-lg">
        <h1 className="text-3xl font-bold mb-6">Login</h1>
        <form onSubmit={handleEmailLogin} className="space-y-4">
          <div>
            <label htmlFor="email" className="block mb-2">Email</label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div>
            <label htmlFor="password" className="block mb-2">Password</label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <Button type="submit" className="w-full">Login with Email</Button>
        </form>
        <div className="mt-4 space-y-2">
          <Button onClick={() => handleSSOLogin('google')} className="w-full bg-red-600 hover:bg-red-700">
            Login with Google
          </Button>
          <Button onClick={() => handleSSOLogin('facebook')} className="w-full bg-blue-600 hover:bg-blue-700">
            Login with Facebook
          </Button>
        </div>
      </div>
    </div>
  )
}

