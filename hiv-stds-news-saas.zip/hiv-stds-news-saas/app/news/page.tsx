import Link from "next/link"
import { Button } from "@/components/ui/button"

// Mock data
const newsItems = [
  {
    id: '1',
    title: 'New HIV Treatment Shows Promise',
    content: 'A new study shows promising results for a novel HIV treatment...',
    source: 'Medical Journal',
    createdAt: new Date().toISOString(),
    url: 'https://example.com/news/1'
  },
  {
    id: '2',
    title: 'STD Prevention Campaign Launched',
    content: 'Health officials have launched a new campaign to prevent STDs...',
    source: 'Public Health Department',
    createdAt: new Date().toISOString(),
    url: 'https://example.com/news/2'
  },
]

export default function NewsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Latest HIV/STDs News</h1>
      <div className="space-y-6">
        {newsItems.map((item) => (
          <div key={item.id} className="bg-secondary/50 backdrop-blur-md p-6 rounded-lg">
            <h2 className="text-xl font-semibold mb-2">{item.title}</h2>
            <p className="text-sm text-muted-foreground mb-2">Source: {item.source}</p>
            <p className="text-sm text-muted-foreground mb-4">
              {new Date(item.createdAt).toLocaleDateString()}
            </p>
            <p className="mb-4">{item.content.substring(0, 200)}...</p>
            <Button asChild>
              <Link href={item.url} target="_blank" rel="noopener noreferrer">
                Read Full Article
              </Link>
            </Button>
          </div>
        ))}
      </div>
    </div>
  )
}

