import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"
import Image from "next/image"
import Link from "next/link"

export default function Home() {
  return (
    <div className="container mx-auto px-4 py-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center max-w-3xl mx-auto"
      >
        <Image 
          src="/temp_image_8eeb2456-3735-44bd-ae00-02d053d5a826.png.jpg" 
          alt="Red AIDS awareness ribbon" 
          width={200} 
          height={240} 
          className="mx-auto mb-8"
        />
        <h1 className="text-4xl font-bold mb-6 text-secondary">YOU DON'T STAND ALONE.</h1>
        <h2 className="text-3xl font-bold mb-6 text-primary">WE PROMISE</h2>
        <p className="text-xl mb-8 text-muted-foreground">
          Step up with us in the fight against HIV and STDs. Together, we are stronger.
        </p>
        <Button asChild size="lg" className="text-lg px-8">
          <Link href="/news">
            Get Latest Updates
          </Link>
        </Button>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.5 }}
        className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8"
      >
        <div className="bg-card p-6 rounded-lg shadow-lg border">
          <h2 className="text-2xl font-semibold mb-4 text-secondary">Real-time Updates</h2>
          <p className="text-muted-foreground">Stay informed with the latest news and research on HIV and STDs.</p>
        </div>
        <div className="bg-card p-6 rounded-lg shadow-lg border">
          <h2 className="text-2xl font-semibold mb-4 text-secondary">Community Support</h2>
          <p className="text-muted-foreground">Connect with others and share experiences in a safe, supportive environment.</p>
        </div>
        <div className="bg-card p-6 rounded-lg shadow-lg border">
          <h2 className="text-2xl font-semibold mb-4 text-secondary">Expert Resources</h2>
          <p className="text-muted-foreground">Access valuable information and guidance from healthcare professionals.</p>
        </div>
      </motion.div>
    </div>
  )
}

