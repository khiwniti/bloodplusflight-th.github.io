"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Checkbox } from "@/components/ui/checkbox"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"

export default function SystemSettingsForm() {
  const [maintenanceMode, setMaintenanceMode] = useState(false)
  const [maxNewsItems, setMaxNewsItems] = useState("100")
  const router = useRouter()
  const supabase = createClientComponentClient()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const { error } = await supabase
      .from('system_settings')
      .upsert({ 
        key: 'general',
        settings: { maintenanceMode, maxNewsItems: parseInt(maxNewsItems) }
      })

    if (error) {
      console.error("Error updating system settings:", error)
    } else {
      router.refresh()
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="flex items-center space-x-2">
        <Checkbox 
          id="maintenanceMode" 
          checked={maintenanceMode} 
          onCheckedChange={(checked) => setMaintenanceMode(checked as boolean)}
        />
        <label htmlFor="maintenanceMode">Maintenance Mode</label>
      </div>
      <div>
        <label htmlFor="maxNewsItems" className="block mb-2">Max News Items</label>
        <Input
          id="maxNewsItems"
          type="number"
          value={maxNewsItems}
          onChange={(e) => setMaxNewsItems(e.target.value)}
          required
        />
      </div>
      <Button type="submit">Update Settings</Button>
    </form>
  )
}

