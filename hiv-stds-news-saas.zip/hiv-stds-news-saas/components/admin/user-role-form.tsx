"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { createClientComponentClient } from "@supabase/auth-helpers-nextjs"

export default function UserRoleForm() {
  const [userId, setUserId] = useState("")
  const [roleId, setRoleId] = useState("")
  const router = useRouter()
  const supabase = createClientComponentClient()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const { error } = await supabase
      .from('user_roles')
      .upsert({ user_id: userId, role_id: roleId })

    if (error) {
      console.error("Error assigning role:", error)
    } else {
      setUserId("")
      setRoleId("")
      router.refresh()
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label htmlFor="userId" className="block mb-2">User ID</label>
        <Input
          id="userId"
          value={userId}
          onChange={(e) => setUserId(e.target.value)}
          required
        />
      </div>
      <div>
        <label htmlFor="roleId" className="block mb-2">Role</label>
        <Select value={roleId} onValueChange={setRoleId}>
          <SelectTrigger>
            <SelectValue placeholder="Select a role" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="admin-role-id">Admin</SelectItem>
            <SelectItem value="editor-role-id">Editor</SelectItem>
            <SelectItem value="user-role-id">User</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <Button type="submit">Assign Role</Button>
    </form>
  )
}

