"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

const sources = [
  'WHO', 'UNAIDS', 'CDC', 'NIH NIAID', 'The Global Fund', 'PEPFAR', 'IAS', 'amfAR', 
  'HIV.gov', 'AVERT', 'Elizabeth Glaser Foundation', 'Gates Foundation', 
  'Terrence Higgins Trust', 'IAVI', 'AVAC'
];

export default function AlertForm() {
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")
  const [severity, setSeverity] = useState("LOW")
  const [source, setSource] = useState("")
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const response = await fetch("/api/alerts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, content, severity, source }),
    })
    if (response.ok) {
      setTitle("")
      setContent("")
      setSeverity("LOW")
      setSource("")
      router.refresh()
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label htmlFor="title" className="block mb-2">Title</label>
        <Input
          id="title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
      </div>
      <div>
        <label htmlFor="content" className="block mb-2">Content</label>
        <Textarea
          id="content"
          value={content}
          onChange={(e) => setContent(e.target.value)}
          required
        />
      </div>
      <div>
        <label htmlFor="severity" className="block mb-2">Severity</label>
        <Select value={severity} onValueChange={setSeverity}>
          <SelectTrigger>
            <SelectValue placeholder="Select severity" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="LOW">Low</SelectItem>
            <SelectItem value="MEDIUM">Medium</SelectItem>
            <SelectItem value="HIGH">High</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div>
        <label htmlFor="source" className="block mb-2">Source</label>
        <Select value={source} onValueChange={setSource}>
          <SelectTrigger>
            <SelectValue placeholder="Select source" />
          </SelectTrigger>
          <SelectContent>
            {sources.map((src) => (
              <SelectItem key={src} value={src}>{src}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <Button type="submit">Create Alert</Button>
    </form>
  )
}

