"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"

type Alert = {
  id: string
  title: string
  content: string
  severity: "LOW" | "MEDIUM" | "HIGH"
  isActive: boolean
}

export default function AlertList({ alerts: initialAlerts }: { alerts: Alert[] }) {
  const [alerts, setAlerts] = useState(initialAlerts)
  const router = useRouter()

  const toggleAlert = async (id: string, isActive: boolean) => {
    const response = await fetch(`/api/alerts/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isActive }),
    })
    if (response.ok) {
      setAlerts(alerts.map(alert => 
        alert.id === id ? { ...alert, isActive } : alert
      ))
    }
  }

  const deleteAlert = async (id: string) => {
    const response = await fetch(`/api/alerts/${id}`, {
      method: "DELETE",
    })
    if (response.ok) {
      setAlerts(alerts.filter(alert => alert.id !== id))
      router.refresh()
    }
  }

  return (
    <div className="space-y-4">
      {alerts.map((alert) => (
        <div key={alert.id} className="bg-secondary/50 backdrop-blur-md p-4 rounded-lg">
          <h3 className="text-lg font-semibold">{alert.title}</h3>
          <p className="text-sm text-muted-foreground mb-2">{alert.content}</p>
          <div className="flex items-center justify-between">
            <span className={`text-xs font-semibold px-2 py-1 rounded ${
              alert.severity === "HIGH" ? "bg-red-500" :
              alert.severity === "MEDIUM" ? "bg-yellow-500" : "bg-green-500"
            }`}>
              {alert.severity}
            </span>
            <div className="flex items-center space-x-2">
              <Switch
                checked={alert.isActive}
                onCheckedChange={(checked) => toggleAlert(alert.id, checked)}
              />
              <Button variant="destructive" size="sm" onClick={() => deleteAlert(alert.id)}>
                Delete
              </Button>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

