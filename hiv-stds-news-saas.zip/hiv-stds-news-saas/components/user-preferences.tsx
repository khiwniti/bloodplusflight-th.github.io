"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"

type Preference = {
  id: string
  keywords: string[]
  sources: string[]
  severity: "LOW" | "MEDIUM" | "HIGH"
}

type PlatformPreference = {
  discordId?: string
  telegramId?: string
  lineId?: string
}

export default function UserPreferences({ preferences, platformPreferences }: { preferences: Preference[], platformPreferences: PlatformPreference }) {
  const [keyword, setKeyword] = useState("")
  const [source, setSource] = useState("")
  const [severity, setSeverity] = useState("LOW")
  const [discordId, setDiscordId] = useState(platformPreferences.discordId || "")
  const [telegramId, setTelegramId] = useState(platformPreferences.telegramId || "")
  const [lineId, setLineId] = useState(platformPreferences.lineId || "")
  const [useDiscord, setUseDiscord] = useState(!!platformPreferences.discordId)
  const [useTelegram, setUseTelegram] = useState(!!platformPreferences.telegramId)
  const [useLine, setUseLine] = useState(!!platformPreferences.lineId)
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const response = await fetch("/api/user/preferences", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ keywords: [keyword], sources: [source], severity }),
    })
    if (response.ok) {
      setKeyword("")
      setSource("")
      setSeverity("LOW")
      router.refresh()
    }
  }

  const handlePlatformSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const response = await fetch("/api/user/platform-preferences", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        discordId: useDiscord ? discordId : null,
        telegramId: useTelegram ? telegramId : null,
        lineId: useLine ? lineId : null,
      }),
    })
    if (response.ok) {
      router.refresh()
    }
  }

  return (
    <div>
      <form onSubmit={handleSubmit} className="space-y-4 mb-8">
        {/* Existing form fields */}
      </form>

      <h3 className="text-xl font-semibold mb-4">Platform Preferences</h3>
      <form onSubmit={handlePlatformSubmit} className="space-y-4 mb-8">
        <div className="flex items-center space-x-2">
          <Checkbox id="useDiscord" checked={useDiscord} onCheckedChange={setUseDiscord} />
          <label htmlFor="useDiscord">Use Discord</label>
        </div>
        {useDiscord && (
          <Input
            id="discordId"
            value={discordId}
            onChange={(e) => setDiscordId(e.target.value)}
            placeholder="Discord User ID"
          />
        )}

        <div className="flex items-center space-x-2">
          <Checkbox id="useTelegram" checked={useTelegram} onCheckedChange={setUseTelegram} />
          <label htmlFor="useTelegram">Use Telegram</label>
        </div>
        {useTelegram && (
          <Input
            id="telegramId"
            value={telegramId}
            onChange={(e) => setTelegramId(e.target.value)}
            placeholder="Telegram User ID"
          />
        )}

        <div className="flex items-center space-x-2">
          <Checkbox id="useLine" checked={useLine} onCheckedChange={setUseLine} />
          <label htmlFor="useLine">Use Line</label>
        </div>
        {useLine && (
          <Input
            id="lineId"
            value={lineId}
            onChange={(e) => setLineId(e.target.value)}
            placeholder="Line User ID"
          />
        )}

        <Button type="submit">Save Platform Preferences</Button>
      </form>

      <h3 className="text-xl font-semibold mb-4">Your Current Preferences</h3>
      {preferences.map((pref) => (
        <div key={pref.id} className="bg-secondary/50 backdrop-blur-md p-4 rounded-lg mb-4">
          <p><strong>Keywords:</strong> {pref.keywords.join(", ")}</p>
          <p><strong>Sources:</strong> {pref.sources.join(", ")}</p>
          <p><strong>Minimum Severity:</strong> {pref.severity}</p>
        </div>
      ))}
    </div>
  )
}

