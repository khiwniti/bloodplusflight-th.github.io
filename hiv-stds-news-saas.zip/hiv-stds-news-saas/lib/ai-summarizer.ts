import { Configuration, OpenAIApi } from 'openai';
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

export async function summarizeNewsAndCreateBlog() {
  const { data: unsummarizedNews, error: fetchError } = await supabase
    .from('news_items')
    .select('*')
    .is('summary', null)
    .limit(10) // Process 10 items at a time to avoid rate limits

  if (fetchError) {
    console.error("Error fetching unsummarized news:", fetchError)
    return
  }

  if (!unsummarizedNews) {
    console.log("No unsummarized news items found")
    return
  }

  for (const newsItem of unsummarizedNews) {
    try {
      // Summarize the news
      const summaryPrompt = `Summarize the following news article in 2-3 sentences:

${newsItem.title}

${newsItem.content}`;
      const summaryResponse = await openai.createCompletion({
        model: "text-davinci-002",
        prompt: summaryPrompt,
        max_tokens: 100,
        n: 1,
        stop: null,
        temperature: 0.5,
      });

      const summary = summaryResponse.data.choices[0].text?.trim();

      // Generate a blog post
      const blogPrompt = `Write a detailed blog post based on the following news article. Include relevant information, potential implications, and maintain a neutral, informative tone:

${newsItem.title}

${newsItem.content}`;
      const blogResponse = await openai.createCompletion({
        model: "text-davinci-002",
        prompt: blogPrompt,
        max_tokens: 1000,
        n: 1,
        stop: null,
        temperature: 0.7,
      });

      const blogContent = blogResponse.data.choices[0].text?.trim();

      if (summary && blogContent) {
        // Update the news item with the summary
        const { error: updateError } = await supabase
          .from('news_items')
          .update({ summary })
          .eq('id', newsItem.id)

        if (updateError) {
          console.error(`Error updating news item ${newsItem.id}:`, updateError)
        }

        // Create a new blog post
        const { error: insertError } = await supabase
          .from('blog_posts')
          .insert({
            title: newsItem.title,
            content: blogContent,
            news_item_id: newsItem.id,
          })

        if (insertError) {
          console.error(`Error creating blog post for news item ${newsItem.id}:`, insertError)
        }
      }
    } catch (error) {
      console.error(`Error processing news item ${newsItem.id}:`, error)
    }
  }
}

