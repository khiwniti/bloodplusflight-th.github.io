import { createServerComponentClient } from '@supabase/auth-helpers-nextjs'
import { cookies } from 'next/headers'

export async function checkUserPermission(permission: string): Promise<boolean> {
  const supabase = createServerComponentClient({ cookies })
  
  const { data: { user }, error: authError } = await supabase.auth.getUser()
  if (authError || !user) {
    return false
  }

  const { data: userRoles, error: rolesError } = await supabase
    .from('user_roles')
    .select('role_id')
    .eq('user_id', user.id)

  if (rolesError || !userRoles) {
    console.error("Error fetching user roles:", rolesError)
    return false
  }

  const roleIds = userRoles.map(ur => ur.role_id)

  const { data: permissions, error: permissionsError } = await supabase
    .from('role_permissions')
    .select('permission_id')
    .in('role_id', roleIds)

  if (permissionsError || !permissions) {
    console.error("Error fetching permissions:", permissionsError)
    return false
  }

  const permissionIds = permissions.map(p => p.permission_id)

  const { data: hasPermission, error: checkError } = await supabase
    .from('permissions')
    .select('id')
    .eq('name', permission)
    .in('id', permissionIds)
    .maybeSingle()

  if (checkError) {
    console.error("Error checking permission:", checkError)
    return false
  }

  return !!hasPermission
}

