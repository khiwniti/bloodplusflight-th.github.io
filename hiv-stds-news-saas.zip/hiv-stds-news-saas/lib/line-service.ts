import { Client } from '@line/bot-sdk';

const client = new Client({
  channelAccessToken: process.env.LINE_CHANNEL_ACCESS_TOKEN,
  channelSecret: process.env.LINE_CHANNEL_SECRET,
});

export async function sendLineMessage(userId: string, message: string) {
  try {
    await client.pushMessage(userId, { type: 'text', text: message });
  } catch (error) {
    console.error('Error sending Line message:', error);
  }
}

