import axios from 'axios';
import * as cheerio from 'cheerio';
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

const sources = [
  { name: 'WHO', url: 'https://www.who.int/news-room/fact-sheets/detail/hiv-aids' },
  { name: 'UNAIDS', url: 'https://www.unaids.org/en/news' },
  { name: 'CDC', url: 'https://www.cdc.gov/hiv/default.html' },
  { name: 'NIH NIAID', url: 'https://www.niaid.nih.gov/diseases-conditions/hivaids' },
  { name: 'The Global Fund', url: 'https://www.theglobalfund.org/en/news/' },
  { name: 'PEPFAR', url: 'https://www.state.gov/pepfar/' },
  { name: 'IAS', url: 'https://www.iasociety.org/news' },
  { name: 'amfAR', url: 'https://www.amfar.org/news/' },
  { name: 'HIV.gov', url: 'https://www.hiv.gov/blog' },
  { name: 'AVERT', url: 'https://www.avert.org/news' },
  { name: 'Elizabeth Glaser Foundation', url: 'https://www.pedaids.org/news-events/' },
  { name: 'Gates Foundation', url: 'https://www.gatesfoundation.org/our-work/programs/global-health/hiv' },
  { name: 'Terrence Higgins Trust', url: 'https://www.tht.org.uk/news' },
  { name: 'IAVI', url: 'https://www.iavi.org/newsroom' },
  { name: 'AVAC', url: 'https://www.avac.org/news' },
];

export async function scrapeNews() {
  for (const source of sources) {
    try {
      const response = await axios.get(source.url);
      const $ = cheerio.load(response.data);

      // This is a basic scraper. You may need to adjust the selectors for each source.
      $('article, .news-item, .blog-post').each(async (_, element) => {
        const title = $(element).find('h2, h3, .title').first().text().trim();
        const content = $(element).find('p, .content, .excerpt').first().text().trim();
        const url = $(element).find('a').attr('href');

        if (title && content && url) {
          const fullUrl = new URL(url, source.url).toString();
          
          // Check if the news item already exists
          const { data: existingNews, error: selectError } = await supabase
            .from('news_items')
            .select('id')
            .eq('title', title)
            .eq('source', source.name)
            .maybeSingle()

          if (selectError) {
            console.error(`Error checking for existing news:`, selectError)
          } else if (!existingNews) {
            const { error: insertError } = await supabase
              .from('news_items')
              .insert({
                title,
                content,
                summary: '', // This will be filled by the AI agent
                source: source.name,
                url: fullUrl,
              })

            if (insertError) {
              console.error(`Error inserting news item:`, insertError)
            }
          }
        }
      });

      console.log(`Successfully scraped news from ${source.name}`);
    } catch (error) {
      console.error(`Error scraping ${source.name}:`, error);
    }
  }
}

