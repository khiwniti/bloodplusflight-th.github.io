import { createClient } from '@supabase/supabase-js'
import { sendTelegramMessage } from './telegram-service'
import { sendLineMessage } from './line-service'

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

export async function sendAlert(alertId: string) {
  const { data: alert, error } = await supabase
    .from('alerts')
    .select('*')
    .eq('id', alertId)
    .single()

  if (error || !alert) {
    console.error("Error fetching alert:", error)
    return
  }

  const { data: users, error: usersError } = await supabase
    .from('user_alert_preferences')
    .select('user_id, telegram_id, line_id')
    .eq('alert_id', alertId)

  if (usersError) {
    console.error("Error fetching user preferences:", usersError)
    return
  }

  for (const user of users || []) {
    if (user.telegram_id) {
      await sendTelegramMessage(user.telegram_id, `${alert.title}\n\n${alert.content}`)
    }

    if (user.line_id) {
      await sendLineMessage(user.line_id, `${alert.title}\n\n${alert.content}`)
    }
  }
}

