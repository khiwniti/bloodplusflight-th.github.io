import { Telegraf } from 'telegraf';

const bot = new Telegraf(process.env.TELEGRAM_BOT_TOKEN);

bot.launch();

export async function sendTelegramMessage(userId: string, message: string) {
  try {
    await bot.telegram.sendMessage(userId, message);
  } catch (error) {
    console.error('Error sending Telegram message:', error);
  }
}

