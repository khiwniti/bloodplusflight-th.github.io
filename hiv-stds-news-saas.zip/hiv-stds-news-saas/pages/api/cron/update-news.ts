import { NextApiRequest, NextApiResponse } from 'next';
import { scrapeNews } from '@/lib/news-scraper';
import { summarizeNewsAndCreateBlog } from '@/lib/ai-summarizer';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    // Verify the request is coming from a legitimate cron job
    const cronSecret = req.headers['x-cron-secret'];
    if (cronSecret !== process.env.CRON_SECRET) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      await scrapeNews();
      await summarizeNewsAndCreateBlog();
      res.status(200).json({ message: 'News updated and blogs created successfully' });
    } catch (error) {
      console.error('Error updating news and creating blogs:', error);
      res.status(500).json({ error: 'Error updating news and creating blogs' });
    }
  } else {
    res.setHeader('Allow', ['POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}

