-- Create the news_articles table
CREATE TABLE public.news_articles (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    summary TEXT,
    source TEXT NOT NULL,
    url TEXT NOT NULL,
    published_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- Enable Row Level Security (RLS)
ALTER TABLE public.news_articles ENABLE ROW LEVEL SECURITY;

-- Create a policy to allow read access to all authenticated users
CREATE POLICY "Allow read access for all authenticated users" 
    ON public.news_articles FOR SELECT 
    USING (auth.role() = 'authenticated');

-- Create a policy to allow insert and update for authenticated users with the 'editor' role
CREATE POLICY "Allow insert and update for editors" 
    ON public.news_articles FOR ALL 
    USING (auth.uid() IN (
        SELECT user_id FROM public.user_roles WHERE role = 'editor'
    ));

-- Create an index on the published_at column for faster querying
CREATE INDEX idx_news_articles_published_at ON public.news_articles (published_at);

-- Create a function to automatically update the updated_at column
CREATE OR REPLACE FUNCTION update_modified_column() 
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create a trigger to call the update_modified_column function
CREATE TRIGGER update_news_articles_modtime 
    BEFORE UPDATE ON public.news_articles 
    FOR EACH ROW 
    EXECUTE FUNCTION update_modified_column();

