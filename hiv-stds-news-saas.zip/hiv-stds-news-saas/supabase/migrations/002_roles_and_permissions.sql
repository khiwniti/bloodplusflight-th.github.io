-- Create roles table
CREATE TABLE public.roles (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- Create permissions table
CREATE TABLE public.permissions (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- Create role_permissions junction table
CREATE TABLE public.role_permissions (
  role_id UUID REFERENCES public.roles(id) ON DELETE CASCADE,
  permission_id UUID REFERENCES public.permissions(id) ON DELETE CASCADE,
  PRIMARY KEY (role_id, permission_id)
);

-- Create user_roles junction table
CREATE TABLE public.user_roles (
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  role_id UUID REFERENCES public.roles(id) ON DELETE CASCADE,
  PRIMARY KEY (user_id, role_id)
);

-- Insert default roles
INSERT INTO public.roles (name) VALUES ('admin'), ('editor'), ('user');

-- Insert default permissions
INSERT INTO public.permissions (name) VALUES 
('manage_users'), ('manage_roles'), ('manage_alerts'), 
('edit_content'), ('view_analytics'), ('manage_system');

-- Assign default permissions to roles
INSERT INTO public.role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM public.roles r, public.permissions p
WHERE 
  (r.name = 'admin') OR
  (r.name = 'editor' AND p.name IN ('edit_content', 'view_analytics')) OR
  (r.name = 'user' AND p.name = 'view_analytics');

-- Update users table to include default role
ALTER TABLE auth.users ADD COLUMN default_role_id UUID REFERENCES public.roles(id);

-- Create a function to assign default role to new users
CREATE OR REPLACE FUNCTION public.assign_default_role() 
RETURNS TRIGGER AS $$
DECLARE
  default_role_id UUID;
BEGIN
  SELECT id INTO default_role_id FROM public.roles WHERE name = 'user';
  
  UPDATE auth.users SET default_role_id = default_role_id WHERE id = NEW.id;
  
  INSERT INTO public.user_roles (user_id, role_id)
  VALUES (NEW.id, default_role_id);
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create a trigger to assign default role to new users
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.assign_default_role();

-- Add RLS policies
ALTER TABLE public.roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow read access to all authenticated users" ON public.roles
  FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Allow all access to admins" ON public.roles
  USING (EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role_id = (SELECT id FROM public.roles WHERE name = 'admin')));

ALTER TABLE public.permissions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow read access to all authenticated users" ON public.permissions
  FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Allow all access to admins" ON public.permissions
  USING (EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role_id = (SELECT id FROM public.roles WHERE name = 'admin')));

ALTER TABLE public.role_permissions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow read access to all authenticated users" ON public.role_permissions
  FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Allow all access to admins" ON public.role_permissions
  USING (EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role_id = (SELECT id FROM public.roles WHERE name = 'admin')));

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow users to view their own roles" ON public.user_roles
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Allow admins to manage user roles" ON public.user_roles
  USING (EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = auth.uid() AND role_id = (SELECT id FROM public.roles WHERE name = 'admin')));

